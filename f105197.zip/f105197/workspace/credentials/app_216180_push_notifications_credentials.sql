prompt --workspace/credentials/app_216180_push_notifications_credentials
begin
--   Manifest
--     CREDENTIAL: App 216180 Push Notifications Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
wwv_imp_workspace.create_credential(
 p_id=>44524091785721421053
,p_name=>'App 216180 Push Notifications Credentials'
,p_static_id=>'App_216180_Push_Notifications_Credentials'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
