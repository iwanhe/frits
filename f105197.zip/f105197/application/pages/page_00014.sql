prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Apply Form Request IT'
,p_alias=>'APPLY-FORM-REQUEST-IT'
,p_step_title=>'Apply Form Request IT'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49841475516457060136)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(44522571291391419690)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49422072176728039667)
,p_plug_name=>'New Form Request IT'
,p_static_id=>'new-form-request-it'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.empno, e.emp_name, m.emp_name as mgr_name',
'  from emp_1 e, emp_1 m',
' where m.empno(+)=e.mgr',
'   and e.empno=:P14_EMPNO'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49857504246455363764)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49422075451693039700)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_button_name=>'SUBMIT_REQUEST'
,p_static_id=>'submit-request'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit Request'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(49857505115429363773)
,p_branch_name=>'Go To Page 11'
,p_branch_action=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422073651854039682)
,p_name=>'P14_APPROVER_IT'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'IT Request Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:PEMBELIAN IT;PEMBELIAN IT,HR RECRUITMENT JAKARTA;HR RECRUITMENT JAKARTA,HR RECRUITMENT KUDUS;HR RECRUITMENT KUDUS'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422072315468039669)
,p_name=>'P14_EMPNO'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_item_source_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_source=>'EMPNO'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422072443526039670)
,p_name=>'P14_EMP_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_item_source_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Peminta'
,p_source=>'EMP_NAME'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422072753391039673)
,p_name=>'P14_JABATAN_PEMINTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Jabatan Peminta'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select distinct position_title from nti_employee_tbl'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cMaxlength=>250
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'Pilih jabatan atau ketik jika tidak ada'
,p_inline_help_text=>'Hindari special character ampersand &, asterisk *, braces, brackets, comma'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'Y',
  'match_type', 'CONTAINS',
  'min_chars', '2')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422073029752039676)
,p_name=>'P14_JABATAN_PENGGUNA'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Jabatan Pengguna'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select distinct position_title from nti_employee_tbl'
,p_lov_display_null=>'YES'
,p_cSize=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'Pilih jabatan atau ketik jika tidak ada'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'Y',
  'match_type', 'CONTAINS',
  'min_chars', '1')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422073554281039681)
,p_name=>'P14_KETERANGAN'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Keterangan'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Isi dengan keterangan lengkap jikalau belum ada pilihan dari beberapa field diatas'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'Y',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422072855441039674)
,p_name=>'P14_LOKASI_PEMINTA'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Lokasi Peminta'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:KUDUS;KUDUS,JAKARTA;JAKARTA'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422073161526039677)
,p_name=>'P14_LOKASI_PENGGUNA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Lokasi Pengguna'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:JAKARTA;JAKARTA,KUDUS;KUDUS'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422073198551039678)
,p_name=>'P14_MANDATORY_HD_SOFT'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Mandatory Harddisk - Software'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:NOTEBOOK;NOTEBOOK,MOUSE;MOUSE,MOUSE PAD;MOUSE PAD,PC;PC,UNIT CPU;UNIT CPU,EMAIL;EMAIL,HRIS;HRIS'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422072545352039671)
,p_name=>'P14_MGR_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_item_source_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Approver'
,p_source=>'MGR_NAME'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49857507893570363801)
,p_name=>'P14_NO_FORM'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'No Form'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422073492065039680)
,p_name=>'P14_OPTIONAL_HD'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Hak Akses'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:ORACLE EBS;ORACLE EBS,TABLEAU;TABLEAU,PAYROLL;PAYROLL,VPN;VPN,NEXTCLOUD;NEXTCLOUD'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422073326666039679)
,p_name=>'P14_OPTIONAL_SOFT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Optional Software - Hardware'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:AUTOCAD;AUTOCAD,ADOBE PHOTOSHOP;ADOBE PHOTOSHOP,ADOBE ILLUSTRATOR;ADOBE ILLUSTRATOR,ADOBE CREATIVE CLOUD;ADOBE CREATIVE CLOUD,COREL DRAW;COREL DRAW,ZOOM;ZOOM,BACKUP FILE;BACKUP FILE,MEMORY;MEMORY,HARDDISK;HARDDISK,MONITOR;MONITOR,KEYBOARD;KEY'
||'BOARD,PRINTER;PRINTER,FLASHDISK;FLASHDISK,PROCESSOR;PROCESSOR,MOTHERBOARD;MOTHERBOARD,CASING;CASING'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(49422072915623039675)
,p_name=>'P14_PENGGUNA'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(49422072176728039667)
,p_prompt=>'Pengguna'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select employee_name from nti_employee_tbl'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'Isi dengan nama pengguna, pilih dari daftar, jika tidak maka diketik manual'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'Y',
  'match_type', 'CONTAINS',
  'min_chars', '1')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(60977319738380701952)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create No Form'
,p_static_id=>'create-no-form'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_number number;',
'v_lokasi varchar2(50);',
'v_bulan varchar2(50);',
'v_tahun varchar2(50);',
'begin',
'',
'case when :P14_LOKASI_PEMINTA =''KUDUS'' ',
'then select ''KDS'' into v_lokasi from dual;',
'else select ''JKT'' into v_lokasi from dual;',
'end case;',
'',
'case when :P14_LOKASI_PEMINTA =''KUDUS'' ',
'then select NO_FORM_SEQ_KDS.nextval into v_number from dual;',
'else select NO_FORM_SEQ_JKT.nextval into v_number from dual;',
'end case;',
'',
'',
'select to_char(sysdate,''RM'')',
'into v_bulan',
'from dual;',
'',
'select to_char(sysdate,''YY'') into v_tahun from dual;',
'',
'select v_number||''/CSIT/''||v_lokasi||''/''||v_bulan||''/''||v_tahun into :P14_NO_FORM from dual;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Gagal terbentuk nomor request'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Sukses terbentuk Nomor Request'
,p_internal_uid=>46470523045373849901
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49422073703087039683)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Fetch Employee Details for User'
,p_static_id=>'fetch-employee-details-for-user'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select empno',
'into :P14_EMPNO',
'  from emp_1 ',
' where emp_name=:APP_USER;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>34915277010080187632
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49422072267228039668)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(49422072176728039667)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Apply Form Request IT'
,p_static_id=>'initialize-form-apply-form-request-it'
,p_internal_uid=>34915275574221187617
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49857504128536363763)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(49422072176728039667)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form New Form Request IT'
,p_static_id=>'process-form-new-form-request-it'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'prevent_lost_updates', 'Y',
  'return_primary_keys_after_insert', 'Y',
  'target_type', 'REGION_SOURCE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>35350707435529511712
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49857505234476363774)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SEND_EMAIL'
,p_process_name=>'Send Email'
,p_static_id=>'send-email'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'cc', '&P14_EMP_NAME., nti-mis@nojorono.com',
  'email_template_id', wwv_flow_imp.id(57737609565253832841),
  'from', '&APP_EMAIL.',
  'placeholder_values', wwv_flow_string.join(wwv_flow_t_varchar2(
    '{',
    '    "P14_APPROVER_IT": "&P14_APPROVER_IT.",',
    '    "P14_NO_FORM": "&P14_NO_FORM.",',
    '    "P14_LOKASI_PEMINTA": "&P14_LOKASI_PEMINTA.",',
    '    "P14_PENGGUNA": "&P14_PENGGUNA.",',
    '    "P14_MGR_NAME": "&P14_MGR_NAME.",',
    '    "P14_EMP_NAME": "&P14_EMP_NAME.",',
    '    "P14_JABATAN_PEMINTA": "&P14_JABATAN_PEMINTA.",',
    '    "P14_LOKASI_PENGGUNA": "&P14_LOKASI_PENGGUNA.",',
    '    "P14_MANDATORY_HD_SOFT": "&P14_MANDATORY_HD_SOFT.",',
    '    "P14_OPTIONAL_SOFT": "&P14_OPTIONAL_SOFT.",',
    '    "P14_OPTIONAL_HD": "&P14_OPTIONAL_HD.",',
    '    "P14_KETERANGAN": "&P14_KETERANGAN."',
    '}')),
  'reply_to', 'nti-mis@nojorono.com',
  'send_immediately', 'Y',
  'to', '&P14_MGR_NAME.')).to_clob
,p_process_error_message=>'Email tidak terkirim'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'dan Email berhasil terkirim, Cek email Anda...'
,p_internal_uid=>35350708541469511723
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(60977320070871701955)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SEND_PUSH_NOTIFICATION'
,p_process_name=>'Send Push Notification'
,p_static_id=>'send-push-notification'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'body', '&P14_EMP_NAME. mengirimkan anda permintaan dengan Nomor Form &P14_NO_FORM. Mohon review dari email atau aplikasi FRITS untuk approval',
  'link_target', 'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::P10_TASK_ID:&P10_TASK_ID.',
  'title', 'Pesan dari &P14_APPROVER_IT. - Please Review',
  'to', '&P14_MGR_NAME.')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>46470523377864849904
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49422073827180039684)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CREATE_TASK'
,p_process_name=>'Submit Form Request'
,p_static_id=>'submit-form-request'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'details_primary_key_item', 'P14_EMPNO',
  'task_definition_id', wwv_flow_imp.id(49834821453318849518))).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(49422075451693039700)
,p_process_success_message=>'Form Request IT berhasil dilakukan submission'
,p_internal_uid=>34915277134173187633
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422073986703039685)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837059278652425843)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_APPROVER_IT'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074058049039686)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837058828568425843)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_MGR_NAME'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074112034039687)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837055217338425841)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_JABATAN_PEMINTA'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074193905039688)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837056438598425841)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_JABATAN_PENGGUNA'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074377662039689)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837058435745425843)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_KETERANGAN'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074450442039690)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837055682732425841)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_LOKASI_PEMINTA'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074550465039691)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837056829654425842)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_LOKASI_PENGGUNA'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074631694039692)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837057237163425842)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_MANDATORY_HD_SOFT'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074776984039693)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837058075089425842)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_OPTIONAL_HD'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074828923039694)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837057615525425842)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_OPTIONAL_SOFT'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422074948788039695)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837054844601425841)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_EMP_NAME'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422075050017039696)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837056005188425841)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_PENGGUNA'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422075096023039697)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837054426489425840)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(49422075222791039698)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(49837059653480425843)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'STATIC'
,p_value=>'PENDING'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(60968904700246482661)
,p_page_id=>14
,p_task_def_param_id=>wwv_flow_imp.id(60968904429574482659)
,p_page_process_id=>wwv_flow_imp.id(49422073827180039684)
,p_value_type=>'ITEM'
,p_value=>'P14_NO_FORM'
);
wwv_flow_imp.component_end;
end;
/
