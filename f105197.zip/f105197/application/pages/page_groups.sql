prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 105197
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(44523865324503419884)
,p_group_name=>'Administration'
,p_static_id=>'administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(44524084559707421045)
,p_group_name=>'User Settings'
,p_static_id=>'user-settings'
);
wwv_flow_imp.component_end;
end;
/
