prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'FORM REQUEST IT'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Kontak IT Jikalau menemui kesulitan</p>',
'<p>Dapat dilakukan dengan submit ticket di link berikut <a href="http://bit.ly/ntisupport" target="_blank" rel="noopener noreferrer">bit.ly/ntisupport</a></p>'))
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60977321074016701965)
,p_plug_name=>'Chat'
,p_static_id=>'chat'
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script>',
'  function initFreshChat() {',
'    window.fcWidget.init({',
'      	 token: "d48b3e62-3630-4691-ad69-ab214251859f",',
'	 host: "https://nti-support.freshchat.com"',
'    });',
'  }',
'  function initialize(i,t){var e;i.getElementById(t)?',
'  initFreshChat():((e=i.createElement("script")).id=t,e.async=!0,',
'  e.src="https://nti-support.freshchat.com/js/widget.js",e.onload=initFreshChat,i.head.appendChild(e))}',
'  function initiateCall(){initialize(document,"Freshchat-js-sdk")}',
'  window.addEventListener?window.addEventListener("load",initiateCall,!1):',
'  window.attachEvent("load",initiateCall,!1);',
'</script>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44523873590587419902)
,p_plug_name=>'FORM REQUEST IT'
,p_static_id=>'form-request-it'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43222427233175855257)
,p_plug_name=>'Page Navigation'
,p_static_id=>'page-navigation'
,p_icon_css_classes=>'fa-forms'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured t-Cards--block force-fa-lg:t-Cards--displayIcons:t-Cards--4cols:t-Cards--hideBody:t-Cards--animColorFill'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_list_id=>wwv_flow_imp.id(45442969655814263965)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2888245825625742894
);
wwv_flow_imp.component_end;
end;
/
