prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Review Update Page'
,p_alias=>'REVIEW-UPDATE'
,p_step_title=>'Review Update Page'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76231545598372393390)
,p_plug_name=>'Form Permintaan IT - Update'
,p_static_id=>'form-permintaan-it-update'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'NTI_FORM_REQUEST_IT_TBL'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45693892997556859118)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45693894288121859119)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'CREATE'
,p_confirm_message=>'Anda Yakin ?'
,p_button_condition=>'P5_ID_1'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45693893434058859119)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P5_ID_1'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45693893851604859119)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Update Informasi'
,p_button_position=>'CHANGE'
,p_confirm_message=>'Anda yakin melakukan update ?'
,p_button_condition=>'P5_ID_1'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(45693912689163859140)
,p_branch_name=>'Go To Page 4'
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231555243050393402)
,p_name=>'P5_APPROVER1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Approver Manager'
,p_source=>'APPROVER1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231556054247393402)
,p_name=>'P5_APPROVER2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Approver IT'
,p_source=>'APPROVER2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231556802161393403)
,p_name=>'P5_CREATED_BY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_source=>'CREATED_BY'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231557237863393403)
,p_name=>'P5_CREATION_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_default=>'select sysdate from dual'
,p_item_default_type=>'SQL_QUERY'
,p_source=>'CREATION_DATE'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231555662222393402)
,p_name=>'P5_EMAIL_APPROVER1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Email Manager'
,p_source=>'EMAIL_APPROVER1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231556431312393403)
,p_name=>'P5_EMAIL_APPROVER2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Email Approver IT'
,p_source=>'EMAIL_APPROVER2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'EMAIL',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231554453874393401)
,p_name=>'P5_HAK_AKSES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Hak Akses'
,p_source=>'HAK_AKSES'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Oracle EBS;Oracle EBS,Tableau;Tableau,VPN;VPN,NextCloud;NextCloud'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231548425223393397)
,p_name=>'P5_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_source=>'ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231548061709393396)
,p_name=>'P5_ID_1'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_source=>'ID_1'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231550889836393399)
,p_name=>'P5_JABATAN_PEMINTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Jabatan Peminta'
,p_source=>'JABATAN_PEMINTA'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231552443705393400)
,p_name=>'P5_JABATAN_PENGGUNA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Jabatan Pengguna'
,p_source=>'JABATAN_PENGGUNA'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231554864535393401)
,p_name=>'P5_KETERANGAN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Keterangan'
,p_source=>'KETERANGAN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>'Diisi dengan keterangan tambahan sesuai dengan pilihan diatas ataupun jika belum ada pilihan'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231551290364393399)
,p_name=>'P5_LOKASI_PEMINTA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Lokasi Peminta'
,p_source=>'LOKASI_PEMINTA'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Kudus;Kudus,Jakarta;Jakarta'
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231552883877393400)
,p_name=>'P5_LOKASI_PENGGUNA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Lokasi Pengguna'
,p_source=>'LOKASI_PENGGUNA'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Jakarta;Jakarta,Kudus;Kudus'
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231553250226393400)
,p_name=>'P5_MANDATORY_HD_SOFT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Mandatory Harddisk Software'
,p_source=>'MANDATORY_HD_SOFT'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Notebook;Notebook,Mouse;Mouse,Mouse Pad;Mouse Pad,PC;PC,CPU;CPU,HRIS / HCM;HRIS / HCM,Email;Email'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231550446033393399)
,p_name=>'P5_NIK_PEMINTA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'NIK Peminta'
,p_source=>'NIK_PEMINTA'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select employee_id',
'from nti_employee_tbl',
'where employee_name =:P5_PEMINTA'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'Y',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231552063336393400)
,p_name=>'P5_NIK_PENGGUNA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'NIK Pengguna'
,p_source=>'NIK_PENGGUNA'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select employee_id',
'from nti_employee_tbl',
'where employee_name = :P5_PENGGUNA'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'Y',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231549275443393398)
,p_name=>'P5_NO_URUT_FORM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'No Urut Form'
,p_source=>'NO_URUT_FORM'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231553682225393401)
,p_name=>'P5_OPSIONAL_HD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Opsional Harddisk'
,p_source=>'OPSIONAL_HD'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Memory;Memory,Harddisk;Harddisk,Monitor;Monitor,Keyboard;Keyboard,Printer;Printer,Flashdisk;Flashdisk,Processor;Processor,Motherboard;Motherboard,Casing;Casing'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231554024038393401)
,p_name=>'P5_OPSIONAL_SOFT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Opsional Software'
,p_source=>'OPSIONAL_SOFT'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Autocad;Autocad,Adobe Photoshop;Adobe Photoshop,Adobe Illustrator;Adobe Illustrator,Adobe Creative Cloud;Adobe Creative Cloud,Corel Draw;Corel Draw,Zoom;Zoom,Backup File;Backup File'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231550093737393398)
,p_name=>'P5_PEMINTA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Peminta'
,p_source=>'PEMINTA'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select employee_name',
'from nti_employee_tbl',
'order by 1 asc'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'Y',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231551671799393399)
,p_name=>'P5_PENGGUNA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Pengguna'
,p_source=>'PENGGUNA'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select employee_name',
'from nti_employee_tbl',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'Y',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231558426812393404)
,p_name=>'P5_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:PENDING;PENDING,PARTIALLY APPROVED;PARTIALLY APPROVED,APPROVED;APPROVED,REJECTED;REJECTED'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231549692396393398)
,p_name=>'P5_TGL_PERMINTAAN'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_default=>'select sysdate from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Tanggal Permintaan'
,p_source=>'TGL_PERMINTAAN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231548814759393397)
,p_name=>'P5_TICKET_NUM'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_prompt=>'Ticket Number'
,p_source=>'TICKET_NUM'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>'Isi dengan nomor Ticket (jika ada)'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'numeric')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231557611591393403)
,p_name=>'P5_UPDATED_BY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_source=>'UPDATED_BY'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76231558081938393404)
,p_name=>'P5_UPDATED_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_item_source_plug_id=>wwv_flow_imp.id(76231545598372393390)
,p_source=>'UPDATED_DATE'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45693910946563859136)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(76231545598372393390)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Form Permintaan IT'
,p_static_id=>'initialize-form-form-permintaan-it'
,p_internal_uid=>31187114253557007085
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45693911314935859136)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(76231545598372393390)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Form Permintaan IT'
,p_static_id=>'process-form-form-permintaan-it'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'prevent_lost_updates', 'Y',
  'return_primary_keys_after_insert', 'Y',
  'target_type', 'REGION_SOURCE')).to_clob
,p_process_error_message=>'Update gagal dilakukan, silakan cek kembali data Anda'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Update sudah berhasil dilakukan'
,p_internal_uid=>31187114621929007085
);
wwv_flow_imp.component_end;
end;
/
