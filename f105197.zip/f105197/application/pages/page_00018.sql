prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'CAR Form'
,p_alias=>'CAR-FORM'
,p_step_title=>'CAR Form'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73117634278836460454)
,p_plug_name=>'CAR Form'
,p_static_id=>'car-form'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'NTI_CAR_FORM'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(73117644337590460461)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(73117645716242460462)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'CREATE'
,p_button_condition=>'P18_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(73117644991827460462)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P18_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(73117645327290460462)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_condition=>'P18_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(73117646082163460462)
,p_branch_action=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117638963888460458)
,p_name=>'P18_APPROVE_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_prompt=>'Approve By'
,p_source=>'APPROVE_BY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select emp_name from emp_1 where 1=1'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117639721394460459)
,p_name=>'P18_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select emp_name ',
'--into :P18_CREATED_BY ',
'from emp_1 ',
'where emp_name = :APP_USER'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Created By'
,p_source=>'CREATED_BY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117635724702460456)
,p_name=>'P18_DEPARTEMEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_prompt=>'Departemen'
,p_source=>'DEPARTEMEN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>20
,p_cMaxlength=>50
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117636906147460457)
,p_name=>'P18_DESKRIPSI_ASET'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_default=>'select case when :P18_TYPE = ''LENOVO THINBOOK I5'' then ''1 Unit Lenovo Thinkbook 14 Gen2 i5 (harga @Rp. 14.200.000 exc PPn) untuk user sbb:'' end x  from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Deskripsi Aset'
,p_source=>'DESKRIPSI_ASET'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>32
,p_cMaxlength=>50
,p_cHeight=>5
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'Y',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117634507671460455)
,p_name=>'P18_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_source=>'ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117636525144460457)
,p_name=>'P18_JENIS_PEMBIAYAAN_ASET'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_default=>'Peralatan IT'
,p_prompt=>'Jenis Pembiayaan Aset'
,p_source=>'JENIS_PEMBIAYAAN_ASET'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Bangunan;Bangunan,Peralatan Kantor;Peralatan Kantor,Peralatan IT;Peralatan IT,Pengembangan Software;Pengembangan Software,Peralatan Pabrik QC;Peralatan Pabrik QC,Kendaraan;Kendaraan,Mesin;Mesin,Other;Other'
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117636161497460456)
,p_name=>'P18_NO_FORM_CAR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_prompt=>'No Form Car'
,p_source=>'NO_FORM_CAR'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117635297410460456)
,p_name=>'P18_NO_FORM_IT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_prompt=>'No Form IT'
,p_source=>'NO_FORM_IT'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select no_form from FORM_REQUEST_IT_TRX',
'where status=''APPROVED'' ',
'and no_form is not null ',
'and peminta not in (''HR.RECRUITMENT.JKT@NOJORONO.COM'')',
'order by no_form desc'))
,p_lov_display_null=>'YES'
,p_cSize=>20
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117637769932460457)
,p_name=>'P18_PERKIRAAN_BIAYA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_prompt=>'Perkiraan Biaya'
,p_source=>'PERKIRAAN_BIAYA'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117638153885460458)
,p_name=>'P18_PERKIRAAN_MASA_MANFAAT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_prompt=>'Perkiraan Masa Manfaat (Tahun)'
,p_placeholder=>'misal: 4'
,p_source=>'PERKIRAAN_MASA_MANFAAT'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'numeric')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117638558671460458)
,p_name=>'P18_PREPARED_BY'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_prompt=>'Prepared By'
,p_source=>'PREPARED_BY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select emp_name from emp_1 where 1=1'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'Y',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117639375031460458)
,p_name=>'P18_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_default=>'PENDING'
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC2:PENDING;PENDING,APPROVED;APPROVED,REJECTED;REJECTED'
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117634946956460456)
,p_name=>'P18_TGL_DIBUAT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_default=>'select to_char(sysdate,''DD-MON-YY'') from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Tanggal Dibuat'
,p_source=>'TGL_DIBUAT'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73117637354170460457)
,p_name=>'P18_TUJUAN_JUSTIFIKASI'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_item_source_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_prompt=>'Tujuan Justifikasi'
,p_source=>'TUJUAN_JUSTIFIKASI'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>32
,p_cMaxlength=>50
,p_cHeight=>5
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'Y',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60977321093030701966)
,p_name=>'P18_TYPE'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(73117634278836460454)
,p_prompt=>'Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'STATIC2:LENOVO THINBOOK I3;LENOVO THINBOOK I3,LENOVO THINBOOK I5;LENOVO THINBOOK I5,LENOVO THINBOOK I7;LENOVO THINBOOK I7'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>3033038269190080499
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73117646496841460463)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(73117634278836460454)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form CAR Form'
,p_static_id=>'initialize-form-car-form'
,p_internal_uid=>58610849803834608412
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73117646946653460463)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(73117634278836460454)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form CAR Form'
,p_static_id=>'process-form-car-form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'prevent_lost_updates', 'Y',
  'return_primary_keys_after_insert', 'Y',
  'target_type', 'REGION_SOURCE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>58610850253646608412
);
wwv_flow_imp.component_end;
end;
/
