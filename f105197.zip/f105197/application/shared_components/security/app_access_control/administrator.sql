prompt --application/shared_components/security/app_access_control/administrator
begin
--   Manifest
--     ACL ROLE: Administrator
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(44523863132907419879)
,p_static_id=>'ADMINISTRATOR'
,p_name=>'Administrator'
,p_description=>'Role assigned to application administrators.'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
