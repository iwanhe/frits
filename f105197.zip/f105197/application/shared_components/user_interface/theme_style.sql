prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 42
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(14510481052439558236)
,p_theme_id=>42
,p_name=>'Iris (V1)'
,p_static_id=>'iris-v1'
,p_css_file_urls=>'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Iris.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_FontFamily":"oracle_sans","@g_Nav_Style":"pillar","@g_Header_Style":"dark","@g_Accent-Pillar":"pine"},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#14510481052439558236.css'
,p_theme_roller_read_only=>false
,p_created_on=>wwv_flow_imp.dz('20260704164501Z')
,p_updated_on=>wwv_flow_imp.dz('20260704164501Z')
,p_created_by=>'IWAN.HERDIAN@KCSI-ID.COM'
,p_updated_by=>'IWAN.HERDIAN@KCSI-ID.COM'
);
wwv_flow_imp.component_end;
end;
/
