prompt --application/shared_components/user_interface/lovs/unified_task_list_lov_state
begin
--   Manifest
--     UNIFIED_TASK_LIST.LOV.STATE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(49395801724409227861)
,p_lov_name=>'UNIFIED_TASK_LIST.LOV.STATE'
,p_static_id=>'unified-task-list-lov-state'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val',
'  from table ( apex_approval.get_lov_state )',
' order by insert_order'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'VAL'
,p_display_column_name=>'DISP'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
