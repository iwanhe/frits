prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 105197
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.1'
,p_default_workspace_id=>146726770692635976661
,p_default_application_id=>105197
,p_default_id_offset=>14506796693006852051
,p_default_owner=>'WKSP_KCSI'
);
null;
wwv_flow_imp.component_end;
end;
/
